// ============================================================
// Wii_Render.cpp
// Implements C4JRender using libogc GX for the Wii.
// Replaces the SDL2 + OpenGL implementation in 4J_Render.cpp.
//
// The engine uses OpenGL-style enums via the GL_* constants
// defined in 4J_Render.h; we translate those to GX calls here.
// ============================================================

#include "Wii_Render.h"

#include <ogc/gx.h>
#include <ogc/video.h>
#include <ogc/system.h>
#include <ogcsys.h>
#include <malloc.h>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <cmath>

// ------------------------------------------------------------------
// Forward-declare the singleton defined in this TU
// ------------------------------------------------------------------
C4JRender RenderManager;

// ------------------------------------------------------------------
// Internal state
// ------------------------------------------------------------------
namespace {

// Video
static GXRModeObj* s_rmode       = nullptr;
static void*       s_xfb[2]      = { nullptr, nullptr };
static int         s_xfbIdx      = 0;
static bool        s_shouldClose = false;
static int         s_width       = 640;
static int         s_height      = 480;

// GX FIFO command buffer (256 KB)
static const int   FIFO_SIZE = 256 * 1024;
static void*       s_gpFifo  = nullptr;

// Texture table (simple flat array, 256 slots)
static const int   MAX_TEXTURES = 256;
struct WiiTexture {
    GXTexObj obj;
    void*    data;       // memalign'd RGBA8 texels
    int      width, height;
    bool     used;
};
static WiiTexture s_textures[MAX_TEXTURES];
static int        s_boundTex = -1;

// Projection / modelview matrices (row-major, matches engine expectation)
static Mtx44 s_projMtx;
static Mtx   s_mvMtx;
static int   s_matrixMode = 0x1700; // GL_MODELVIEW

// Render state cache
struct RState {
    bool  depthTest   = true;
    bool  depthMask   = true;
    bool  blend       = false;
    bool  alphaTest   = false;
    bool  cullFace    = false;
    bool  fog         = false;
    bool  lighting    = false;
    float clearR=0, clearG=0, clearB=0, clearA=1;
    GXColor fogColor  = {0,0,0,255};
    float fogNear=1, fogFar=100;
    // colour for StateSetColour
    float colR=1,colG=1,colB=1,colA=1;
};
static RState s_rs;

// ------------------------------------------------------------------
// Helper: 8-bit float → GX component
// ------------------------------------------------------------------
static inline uint8_t f2b(float f) {
    int v = (int)(f * 255.0f + 0.5f);
    return (uint8_t)(v < 0 ? 0 : v > 255 ? 255 : v);
}

// ------------------------------------------------------------------
// Texture init
// ------------------------------------------------------------------
static void initTextures() {
    memset(s_textures, 0, sizeof(s_textures));
}

// ------------------------------------------------------------------
// Apply depth + blend state to GX
// ------------------------------------------------------------------
static void applyDepthBlend() {
    GXCompare depthFn = s_rs.depthTest ? GX_LEQUAL : GX_ALWAYS;
    GX_SetZMode(s_rs.depthTest ? GX_TRUE : GX_FALSE, depthFn,
                s_rs.depthMask ? GX_TRUE : GX_FALSE);

    if (s_rs.blend) {
        GX_SetBlendMode(GX_BM_BLEND, GX_BL_SRCALPHA, GX_BL_INVSRCALPHA, GX_LO_CLEAR);
    } else {
        GX_SetBlendMode(GX_BM_NONE, GX_BL_ONE, GX_BL_ZERO, GX_LO_CLEAR);
    }
    GX_SetAlphaCompare(s_rs.alphaTest ? GX_GREATER : GX_ALWAYS, 0,
                       GX_AOP_AND, GX_ALWAYS, 0);
}

} // namespace

// ==================================================================
// C4JRender Implementation
// ==================================================================

void C4JRender::Initialise() {
    // ----- Video init -----
    VIDEO_Init();
    s_rmode = VIDEO_GetPreferredMode(nullptr);
    s_width  = s_rmode->fbWidth;
    s_height = s_rmode->efbHeight;

    // Allocate two XFBs for double buffering
    s_xfb[0] = MEM_K0_TO_K1(SYS_AllocateFramebuffer(s_rmode));
    s_xfb[1] = MEM_K0_TO_K1(SYS_AllocateFramebuffer(s_rmode));
    VIDEO_Configure(s_rmode);
    VIDEO_SetNextFramebuffer(s_xfb[0]);
    VIDEO_SetBlack(FALSE);
    VIDEO_Flush();
    VIDEO_WaitVSync();
    if (s_rmode->viTVMode & VI_NON_INTERLACE) VIDEO_WaitVSync();

    // ----- GX init -----
    s_gpFifo = memalign(32, FIFO_SIZE);
    memset(s_gpFifo, 0, FIFO_SIZE);
    GX_Init(s_gpFifo, FIFO_SIZE);

    GXColor bgColor = { (uint8_t)(s_rs.clearR*255),
                        (uint8_t)(s_rs.clearG*255),
                        (uint8_t)(s_rs.clearB*255),
                        (uint8_t)(s_rs.clearA*255) };
    GX_SetCopyClear(bgColor, GX_MAX_Z24);
    GX_SetViewport(0, 0, s_rmode->fbWidth, s_rmode->efbHeight, 0, 1);

    float yscale = GX_GetYScaleFactor(s_rmode->efbHeight, s_rmode->xfbHeight);
    uint32_t xfbHeight = GX_SetDispCopyYScale(yscale);
    GX_SetScissor(0, 0, s_rmode->fbWidth, s_rmode->efbHeight);
    GX_SetDispCopySrc(0, 0, s_rmode->fbWidth, s_rmode->efbHeight);
    GX_SetDispCopyDst(s_rmode->fbWidth, xfbHeight);
    GX_SetCopyFilter(s_rmode->aa, s_rmode->sample_pattern, GX_TRUE, s_rmode->vfilter);
    GX_SetFieldMode(s_rmode->field_rendering,
                    (s_rmode->viHeight == 2 * s_rmode->xfbHeight) ? GX_ENABLE : GX_DISABLE);
    GX_SetCullMode(GX_CULL_NONE);
    GX_CopyDisp(s_xfb[s_xfbIdx], GX_TRUE);
    GX_SetDispCopyGamma(GX_GM_1_0);

    // Default vertex format: position (3f) + colour (4u8) + texcoord (2f)
    GX_ClearVtxDesc();
    GX_SetVtxDesc(GX_VA_POS,  GX_DIRECT);
    GX_SetVtxDesc(GX_VA_CLR0, GX_DIRECT);
    GX_SetVtxDesc(GX_VA_TEX0, GX_DIRECT);
    GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_POS,  GX_POS_XYZ,  GX_F32, 0);
    GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_CLR0, GX_CLR_RGBA, GX_RGBA8, 0);
    GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX0, GX_TEX_ST,   GX_F32, 0);

    // Default TEV: modulate texture with vertex colour
    GX_SetNumChans(1);
    GX_SetNumTexGens(1);
    GX_SetTexCoordGen(GX_TEXCOORD0, GX_TG_MTX2x4, GX_TG_TEX0, GX_IDENTITY);
    GX_SetTevOrder(GX_TEVSTAGE0, GX_TEXCOORD0, GX_TEXMAP0, GX_COLOR0A0);
    GX_SetTevOp(GX_TEVSTAGE0, GX_MODULATE);
    GX_SetNumTevStages(1);

    // Default identity matrices
    guMtxIdentity(s_mvMtx);
    GX_LoadPosMtxImm(s_mvMtx, GX_PNMTX0);
    guOrtho(s_projMtx, 0, s_height, 0, s_width, 0, 300);
    GX_LoadProjectionMtx(s_projMtx, GX_ORTHOGRAPHIC);

    applyDepthBlend();
    initTextures();

    printf("[Wii_Render] GX initialised: %dx%d\n", s_width, s_height);
}

void C4JRender::InitialiseContext() {
    // On Wii GX is single-context; nothing extra needed.
}

void C4JRender::SetWindowSize(int w, int h) {
    s_width = w; s_height = h; // Ignored on Wii — TV output is fixed
}
void C4JRender::SetFullscreen(bool) {}

void C4JRender::StartFrame() {
    GX_SetViewport(0, 0, s_rmode->fbWidth, s_rmode->efbHeight, 0, 1);
}

void C4JRender::Present() {
    GX_DrawDone();
    GX_CopyDisp(s_xfb[s_xfbIdx], GX_TRUE);
    VIDEO_SetNextFramebuffer(s_xfb[s_xfbIdx]);
    VIDEO_Flush();
    VIDEO_WaitVSync();
    s_xfbIdx ^= 1;
}

void C4JRender::Clear(int flags) {
    GXColor c = {
        f2b(s_rs.clearR), f2b(s_rs.clearG),
        f2b(s_rs.clearB), f2b(s_rs.clearA)
    };
    GX_SetCopyClear(c, GX_MAX_Z24);
}

void C4JRender::SetClearColour(const float rgba[4]) {
    s_rs.clearR = rgba[0]; s_rs.clearG = rgba[1];
    s_rs.clearB = rgba[2]; s_rs.clearA = rgba[3];
}

bool C4JRender::IsWidescreen()    { return (s_width > s_height); }
bool C4JRender::IsHiDef()         { return false; }
void C4JRender::GetFramebufferSize(int& w, int& h) { w = s_width; h = s_height; }
bool C4JRender::ShouldClose()     { return s_shouldClose; }
void C4JRender::Shutdown()        { s_shouldClose = true; }
void C4JRender::Tick()            {}
void C4JRender::UpdateGamma(unsigned short) {}
void C4JRender::DoScreenGrabOnNextPresent() {}
void C4JRender::CaptureThumbnail(ImageFileBuffer*)  {}
void C4JRender::CaptureScreen(ImageFileBuffer*, XSOCIAL_PREVIEWIMAGE*) {}
void C4JRender::BeginEvent(LPCWSTR) {}
void C4JRender::EndEvent()          {}
void C4JRender::Suspend()           {}
bool C4JRender::Suspended()         { return false; }
void C4JRender::Resume()            {}

// ------------------------------------------------------------------
// Matrix stack
// ------------------------------------------------------------------
void C4JRender::MatrixMode(int m)    { s_matrixMode = m; }
void C4JRender::MatrixSetIdentity()  {
    if (s_matrixMode == 0x1701) { // GL_PROJECTION
        Mtx44 id; memset(id, 0, sizeof(id));
        id[0][0]=id[1][1]=id[2][2]=id[3][3]=1;
        memcpy(s_projMtx, id, sizeof(id));
        GX_LoadProjectionMtx(s_projMtx, GX_PERSPECTIVE);
    } else {
        guMtxIdentity(s_mvMtx);
        GX_LoadPosMtxImm(s_mvMtx, GX_PNMTX0);
    }
}
void C4JRender::MatrixTranslate(float x, float y, float z) {
    Mtx t; guMtxTrans(t, x, y, z);
    Mtx tmp; guMtxConcat(s_mvMtx, t, tmp);
    memcpy(s_mvMtx, tmp, sizeof(s_mvMtx));
    GX_LoadPosMtxImm(s_mvMtx, GX_PNMTX0);
}
void C4JRender::MatrixRotate(float angle, float x, float y, float z) {
    guVector axis = {x, y, z};
    Mtx r; guMtxRotAxisDeg(r, &axis, angle);
    Mtx tmp; guMtxConcat(s_mvMtx, r, tmp);
    memcpy(s_mvMtx, tmp, sizeof(s_mvMtx));
    GX_LoadPosMtxImm(s_mvMtx, GX_PNMTX0);
}
void C4JRender::MatrixScale(float x, float y, float z) {
    Mtx s; guMtxScale(s, x, y, z);
    Mtx tmp; guMtxConcat(s_mvMtx, s, tmp);
    memcpy(s_mvMtx, tmp, sizeof(s_mvMtx));
    GX_LoadPosMtxImm(s_mvMtx, GX_PNMTX0);
}
void C4JRender::MatrixPerspective(float fovy, float aspect, float zNear, float zFar) {
    guPerspective(s_projMtx, fovy, aspect, zNear, zFar);
    GX_LoadProjectionMtx(s_projMtx, GX_PERSPECTIVE);
}
void C4JRender::MatrixOrthogonal(float l, float r, float b, float t, float n, float f) {
    guOrtho(s_projMtx, t, b, l, r, n, f);
    GX_LoadProjectionMtx(s_projMtx, GX_ORTHOGRAPHIC);
}
void C4JRender::MatrixPop()  {}
void C4JRender::MatrixPush() {}
void C4JRender::MatrixMult(float* m) {
    // m is column-major (OpenGL convention); guMtx is row-major
    Mtx gm;
    gm[0][0]=m[0]; gm[0][1]=m[4]; gm[0][2]=m[8];  gm[0][3]=m[12];
    gm[1][0]=m[1]; gm[1][1]=m[5]; gm[1][2]=m[9];  gm[1][3]=m[13];
    gm[2][0]=m[2]; gm[2][1]=m[6]; gm[2][2]=m[10]; gm[2][3]=m[14];
    Mtx tmp; guMtxConcat(s_mvMtx, gm, tmp);
    memcpy(s_mvMtx, tmp, sizeof(s_mvMtx));
    GX_LoadPosMtxImm(s_mvMtx, GX_PNMTX0);
}
const float* C4JRender::MatrixGet(int type) {
    static float buf[16];
    if (type == 0x0BA7) { // GL_PROJECTION_MATRIX
        // Flatten Mtx44 row-major → column-major float[16]
        for (int r=0;r<4;r++) for(int c=0;c<4;c++) buf[c*4+r] = s_projMtx[r][c];
    } else {
        for (int r=0;r<3;r++) for(int c=0;c<4;c++) buf[c*4+r] = s_mvMtx[r][c];
        buf[3]=buf[7]=buf[11]=0; buf[15]=1;
    }
    return buf;
}
void C4JRender::Set_matrixDirty() {
    GX_LoadPosMtxImm(s_mvMtx, GX_PNMTX0);
}

// ------------------------------------------------------------------
// Draw vertices — converts engine vertex soup to GX primitives
// ------------------------------------------------------------------
void C4JRender::DrawVertices(ePrimitiveType pt, int count, void* dataIn,
                              eVertexType vType, ePixelShaderType) {
    if (!dataIn || count <= 0) return;

    // Engine vertex layout: VERTEX_TYPE_PF3_TF2_CB4_NB4_XW1
    // float x,y,z; float s,t; uint8 r,g,b,a; uint8 nx,ny,nz,nw; uint32 pad
    struct EngineVert {
        float x,y,z;
        float s,t;
        uint8_t r,g,b,a;
        uint8_t nx,ny,nz,nw;
        uint32_t pad;
    };
    const EngineVert* verts = (const EngineVert*)dataIn;

    uint8_t gxPrim;
    switch (pt) {
        case PRIMITIVE_TYPE_TRIANGLE_LIST:  gxPrim = GX_TRIANGLES;    break;
        case PRIMITIVE_TYPE_TRIANGLE_STRIP: gxPrim = GX_TRIANGLESTRIP;break;
        case PRIMITIVE_TYPE_TRIANGLE_FAN:   gxPrim = GX_TRIANGLEFAN;  break;
        case PRIMITIVE_TYPE_QUAD_LIST:      gxPrim = GX_QUADS;        break;
        case PRIMITIVE_TYPE_LINE_LIST:      gxPrim = GX_LINES;        break;
        case PRIMITIVE_TYPE_LINE_STRIP:     gxPrim = GX_LINESTRIP;    break;
        default:                            gxPrim = GX_TRIANGLES;    break;
    }

    GX_Begin(gxPrim, GX_VTXFMT0, count);
    for (int i = 0; i < count; i++) {
        const EngineVert& v = verts[i];
        GX_Position3f32(v.x, v.y, v.z);
        GX_Color4u8(v.r, v.g, v.b, v.a);
        GX_TexCoord2f32(v.s, v.t);
    }
    GX_End();
}

// ------------------------------------------------------------------
// Command buffers — on Wii these are simple no-ops (GX handles
// its own FIFO). We return a stable "always valid" sentinel.
// ------------------------------------------------------------------
static const int CBUFF_SENTINEL = 1;
void C4JRender::CBuffLockStaticCreations() {}
int  C4JRender::CBuffCreate(int)            { return CBUFF_SENTINEL; }
void C4JRender::CBuffDelete(int, int)       {}
void C4JRender::CBuffStart(int, bool)       {}
void C4JRender::CBuffClear(int)             {}
int  C4JRender::CBuffSize(int)              { return 0; }
void C4JRender::CBuffEnd()                  {}
bool C4JRender::CBuffCall(int, bool)        { return true; }
void C4JRender::CBuffTick()                 {}
void C4JRender::CBuffDeferredModeStart()    {}
void C4JRender::CBuffDeferredModeEnd()      {}
void C4JRender::BeginConditionalSurvey(int) {}
void C4JRender::EndConditionalSurvey()      {}
void C4JRender::BeginConditionalRendering(int) {}
void C4JRender::EndConditionalRendering()      {}

// ------------------------------------------------------------------
// Textures
// ------------------------------------------------------------------
int C4JRender::TextureCreate() {
    for (int i = 0; i < MAX_TEXTURES; i++) {
        if (!s_textures[i].used) {
            s_textures[i].used = true;
            s_textures[i].data = nullptr;
            s_textures[i].width = s_textures[i].height = 0;
            return i;
        }
    }
    return -1;
}
void C4JRender::TextureFree(int idx) {
    if (idx < 0 || idx >= MAX_TEXTURES) return;
    if (s_textures[idx].data) { free(s_textures[idx].data); s_textures[idx].data = nullptr; }
    s_textures[idx].used = false;
}
void C4JRender::TextureBind(int idx) {
    if (idx < 0 || idx >= MAX_TEXTURES || !s_textures[idx].used) return;
    s_boundTex = idx;
    GX_LoadTexObj(&s_textures[idx].obj, GX_TEXMAP0);
}
void C4JRender::TextureBindVertex(int idx, bool) { TextureBind(idx); }
void C4JRender::TextureSetTextureLevels(int) {}
int  C4JRender::TextureGetTextureLevels()    { return 1; }

void C4JRender::TextureData(int w, int h, void* data, int /*level*/,
                             eTextureFormat fmt) {
    if (s_boundTex < 0) return;
    WiiTexture& t = s_textures[s_boundTex];
    if (t.data) { free(t.data); t.data = nullptr; }
    t.width = w; t.height = h;

    // GX requires 32-byte aligned RGBA8 data in a tiled layout.
    // Engine provides linear RGBA8; we copy and let GX_InitTexObj handle it.
    size_t bytes = (size_t)(w * h * 4);
    t.data = memalign(32, bytes);
    if (!t.data) return;
    if (data) memcpy(t.data, data, bytes);
    DCFlushRange(t.data, bytes);

    GX_InitTexObj(&t.obj, t.data, (uint16_t)w, (uint16_t)h,
                  GX_TF_RGBA8, GX_CLAMP, GX_CLAMP, GX_FALSE);
    GX_InitTexObjLOD(&t.obj, GX_NEAR, GX_NEAR, 0, 0, 0, GX_FALSE, GX_FALSE, GX_ANISO_1);
    GX_LoadTexObj(&t.obj, GX_TEXMAP0);
}

void C4JRender::TextureDataUpdate(int xoff, int yoff, int w, int h,
                                   void* data, int) {
    if (s_boundTex < 0 || !data) return;
    WiiTexture& t = s_textures[s_boundTex];
    if (!t.data) return;
    // Simple sub-image copy into the linear buffer then re-upload
    uint8_t* dst = (uint8_t*)t.data;
    uint8_t* src = (uint8_t*)data;
    for (int y = 0; y < h; y++) {
        memcpy(dst + ((yoff+y)*t.width + xoff)*4, src + y*w*4, w*4);
    }
    DCFlushRange(t.data, (size_t)(t.width * t.height * 4));
    GX_InitTexObj(&t.obj, t.data, (uint16_t)t.width, (uint16_t)t.height,
                  GX_TF_RGBA8, GX_CLAMP, GX_CLAMP, GX_FALSE);
    GX_LoadTexObj(&t.obj, GX_TEXMAP0);
}

void C4JRender::TextureSetParam(int param, int value) {
    // GX wrap/filter are set during GX_InitTexObj; re-init if needed.
    // For now, silently accept (most defaults are fine).
}
void C4JRender::TextureDynamicUpdateStart() {}
void C4JRender::TextureDynamicUpdateEnd()   {}
void C4JRender::TextureGetStats()           {}
void* C4JRender::TextureGetTexture(int idx) {
    if (idx < 0 || idx >= MAX_TEXTURES) return nullptr;
    return s_textures[idx].data;
}

HRESULT C4JRender::LoadTextureData(const char* path, D3DXIMAGE_INFO* info, int** out) {
    // Not implemented on Wii — engine loads textures via its own asset system
    return -1;
}
HRESULT C4JRender::LoadTextureData(uint8_t*, uint32_t, D3DXIMAGE_INFO*, int**) { return -1; }
HRESULT C4JRender::SaveTextureData(const char*, D3DXIMAGE_INFO*, int*) { return -1; }
HRESULT C4JRender::SaveTextureDataToMemory(void*, int, int*, int, int, int*) { return -1; }

// ------------------------------------------------------------------
// Render state
// ------------------------------------------------------------------
void C4JRender::StateSetColour(float r, float g, float b, float a) {
    s_rs.colR=r; s_rs.colG=g; s_rs.colB=b; s_rs.colA=a;
    GXColor c = { f2b(r), f2b(g), f2b(b), f2b(a) };
    GX_SetTevColor(GX_TEVREG0, c);
}
void C4JRender::StateSetDepthMask(bool e) { s_rs.depthMask=e; applyDepthBlend(); }
void C4JRender::StateSetBlendEnable(bool e) { s_rs.blend=e; applyDepthBlend(); }
void C4JRender::StateSetBlendFunc(int, int) { applyDepthBlend(); }
void C4JRender::StateSetBlendFactor(unsigned int) {}
void C4JRender::StateSetAlphaFunc(int, float) { applyDepthBlend(); }
void C4JRender::StateSetDepthFunc(int) { applyDepthBlend(); }
void C4JRender::StateSetFaceCull(bool e) {
    s_rs.cullFace = e;
    GX_SetCullMode(e ? GX_CULL_BACK : GX_CULL_NONE);
}
void C4JRender::StateSetFaceCullCW(bool e) {
    GX_SetCullMode(e ? GX_CULL_FRONT : GX_CULL_NONE);
}
void C4JRender::StateSetLineWidth(float w) { GX_SetLineWidth((uint8_t)(w*6), GX_TO_ZERO); }
void C4JRender::StateSetWriteEnable(bool r, bool g, bool b, bool a) {}
void C4JRender::StateSetDepthTestEnable(bool e) { s_rs.depthTest=e; applyDepthBlend(); }
void C4JRender::StateSetAlphaTestEnable(bool e) { s_rs.alphaTest=e; applyDepthBlend(); }
void C4JRender::StateSetDepthSlopeAndBias(float, float) {}

void C4JRender::StateSetFogEnable(bool e)        { s_rs.fog=e; }
void C4JRender::StateSetFogMode(int)              {}
void C4JRender::StateSetFogNearDistance(float n)  { s_rs.fogNear=n; }
void C4JRender::StateSetFogFarDistance(float f)   { s_rs.fogFar=f; }
void C4JRender::StateSetFogDensity(float)         {}
void C4JRender::StateSetFogColour(float r, float g, float b) {
    s_rs.fogColor = { f2b(r), f2b(g), f2b(b), 255 };
    if (s_rs.fog)
        GX_SetFog(GX_FOG_LIN, s_rs.fogNear, s_rs.fogFar, 0.1f, 1.0f, s_rs.fogColor);
}

void C4JRender::StateSetLightingEnable(bool)      {}
void C4JRender::StateSetVertexTextureUV(float, float) {}
void C4JRender::StateSetLightColour(int, float, float, float) {}
void C4JRender::StateSetLightAmbientColour(float, float, float) {}
void C4JRender::StateSetLightDirection(int, float, float, float) {}
void C4JRender::StateSetLightEnable(int, bool)    {}

void C4JRender::StateSetViewport(eViewportType vt) {
    float x=0, y=0, w=(float)s_width, h=(float)s_height;
    switch(vt) {
        case VIEWPORT_TYPE_SPLIT_TOP:    h/=2; break;
        case VIEWPORT_TYPE_SPLIT_BOTTOM: y=h/2; h/=2; break;
        case VIEWPORT_TYPE_SPLIT_LEFT:   w/=2; break;
        case VIEWPORT_TYPE_SPLIT_RIGHT:  x=w/2; w/=2; break;
        default: break;
    }
    GX_SetViewport(x, y, w, h, 0, 1);
    GX_SetScissor((int)x, (int)y, (int)w, (int)h);
}
void C4JRender::StateSetEnableViewportClipPlanes(bool) {}
void C4JRender::StateSetTexGenCol(int, float, float, float, float, bool) {}
void C4JRender::StateSetStencil(int, uint8_t, uint8_t, uint8_t) {}
void C4JRender::StateSetForceLOD(int) {}
