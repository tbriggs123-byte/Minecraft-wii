// ============================================================
// Wii_App.cpp
// CWiiMinecraftApp — Wii platform-specific app implementation.
// ============================================================

#include "../../../Minecraft.World/Platform/stdafx.h"
#include "../Common/Consoles_App.h"
#include "../../Player/User.h"
#include "../../Minecraft.h"
#include "../../MinecraftServer.h"
#include "../../Network/PlayerList.h"
#include "../../Player/ServerPlayer.h"
#include "../../../Minecraft.World/Level/Level.h"
#include "../../../Minecraft.World/Level/Storage/LevelSettings.h"
#include "../../../Minecraft.World/WorldGen/Biomes/BiomeSource.h"
#include "../../../Minecraft.World/Level/Storage/LevelType.h"
#include "Wii_App.h"

CWiiMinecraftApp app;

#define CONTEXT_GAME_STATE 0

CWiiMinecraftApp::CWiiMinecraftApp() : CMinecraftApp() {}

void CWiiMinecraftApp::SetRichPresenceContext(int iPad, int contextId) {
    ProfileManager.SetRichPresenceContextValue(iPad, CONTEXT_GAME_STATE, contextId);
}

void CWiiMinecraftApp::ExitGame() {
    // On Wii we return to the Homebrew Channel / loader
#ifdef HW_RVL
    extern void exit(int);
    exit(0);
#endif
}

void CWiiMinecraftApp::FatalLoadError() {
    app.DebugPrintf("CWiiMinecraftApp::FatalLoadError — fatal error, halting\n");
    // Spin forever so the developer can read the screen
    for(;;) {}
}

void CWiiMinecraftApp::TemporaryCreateGameStart() {
    // Direct-boot a creative world for testing
    app.setLevelGenerationOptions(nullptr);

    Minecraft* pMinecraft = Minecraft::GetInstance();
    app.ReleaseSaveThumbnail();
    ProfileManager.SetLockedProfile(0);
    pMinecraft->user->name = L"Wii";
    app.ApplyGameSettingsChanged(0);

    MinecraftServer::resetFlags();
    app.SetTutorialMode(false);
    app.SetCorruptSaveDeleted(false);

    app.ClearTerrainFeaturePosition();
    std::wstring worldName = L"WiiWorld";

    StorageManager.ResetSaveData();
    StorageManager.SetSaveTitle(worldName.c_str());

    NetworkGameInitData* param = new NetworkGameInitData();
    param->seed      = 0;
    param->saveData  = nullptr;

    app.SetGameHostOption(eGameHostOption_Difficulty, 0);
    app.SetGameHostOption(eGameHostOption_GameType, GameType::CREATIVE->getId());
    app.SetGameHostOption(eGameHostOption_LevelType,   0);
    app.SetGameHostOption(eGameHostOption_Structures,  1);
    app.SetGameHostOption(eGameHostOption_BonusChest,  0);
    app.SetGameHostOption(eGameHostOption_FriendsOfFriends, 0);
    app.SetGameHostOption(eGameHostOption_Gamertags,   1);
    app.SetGameHostOption(eGameHostOption_BedrockFog,  1);
    app.SetGameHostOption(eGameHostOption_PvP,         1);
    app.SetGameHostOption(eGameHostOption_TrustPlayers,1);
    app.SetGameHostOption(eGameHostOption_FireSpreads, 1);
    app.SetGameHostOption(eGameHostOption_TNT,         1);
    app.SetGameHostOption(eGameHostOption_HostCanFly,  1);
    app.SetGameHostOption(eGameHostOption_HostCanChangeHunger, 1);
    app.SetGameHostOption(eGameHostOption_HostCanBeInvisible,  1);

    param->settings = app.GetGameHostOption(eGameHostOption_All);

    g_NetworkManager.FakeLocalPlayerJoined();

    LoadingInputParams* loadingParams = new LoadingInputParams();
    loadingParams->func   = &CGameNetworkManager::RunNetworkGameThreadProc;
    loadingParams->lpParam = (LPVOID)param;

    app.SetAutosaveTimerTime();
    C4JThread* thread = new C4JThread(loadingParams->func, loadingParams->lpParam,
                                      "RunNetworkGame");
    thread->Run();
}
