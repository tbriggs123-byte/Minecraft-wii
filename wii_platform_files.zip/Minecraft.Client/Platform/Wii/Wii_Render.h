#pragma once
// ============================================================
// Wii_Render.h
// Includes the engine render manager header after setting up
// all Wii-specific includes so the types resolve correctly.
// ============================================================

#include "Stubs/WiiStubs.h"
#include "../../../4J.Render/4J_Render.h"
