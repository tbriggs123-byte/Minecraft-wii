#pragma once
#ifndef WII_XBOX_STUBS_H
#define WII_XBOX_STUBS_H

// ============================================================
// WiiXboxStubs.h
// Xbox/Windows API stubs for the Wii/devkitPPC build.
// Mirrors xbox_stubs.h and winapi_stubs.h from the Linux layer.
// ============================================================

#define POSIX
#define FORCEINLINE inline

typedef unsigned int  uint;
typedef unsigned long long int uint64;
typedef long long int int64;

// Content flags (unused on Wii)
#define XCONTENTFLAG_NONE              0x00
#define XCONTENTFLAG_CREATENEW         0x00
#define XCONTENTFLAG_CREATEALWAYS      0x00
#define XCONTENTFLAG_OPENEXISTING      0x00
#define XCONTENTFLAG_OPENALWAYS        0x00
#define XCONTENTFLAG_TRUNCATEEXISTING  0x00
#define XCONTENTFLAG_NOPROFILE_TRANSFER  0x00
#define XCONTENTFLAG_NODEVICE_TRANSFER   0x00
#define XCONTENTFLAG_STRONG_SIGNED       0x00
#define XCONTENTFLAG_ALLOWPROFILE_TRANSFER 0x00
#define XCONTENTFLAG_MOVEONLY_TRANSFER   0x00

// Device/user constants
#define XDEVICE_PORT0        0
#define XDEVICE_PORT1        1
#define XDEVICE_PORT2        2
#define XDEVICE_PORT3        3
#define XUSER_INDEX_NONE     0x000000FE
#define XUSER_MAX_COUNT      4

// Title/offer IDs used by the engine
#define TITLEID_MINECRAFT    0x584111F7u
#define PROFILE_VERSION_10   10

// Profile/achievement defines (all no-ops on Wii)
#define XPROFILE_OPTION_CONTROLLER_VIBRATION  0
#define XPROFILE_GAMER_YAXIS_INVERSION        0
#define XPROFILE_GAMER_CONTROL_SENSITIVITY    0
#define XPROFILE_GAMER_ACTION_MOVEMENT_CONTROL 0
#define XPROFILE_TITLE_SPECIFIC1              0
#define XACHIEVEMENT_DETAILS_LABEL_SIZE       64

// printf-style debug output
inline int sprintf_s(char* buf, size_t n, const char* fmt, ...) {
    va_list a; va_start(a, fmt);
    int r = vsnprintf(buf, n, fmt, a);
    va_end(a); return r;
}
inline int swprintf_s(wchar_t* buf, size_t n, const wchar_t* fmt, ...) {
    va_list a; va_start(a, fmt);
    int r = vswprintf(buf, n, fmt, a);
    va_end(a); return r;
}
inline int _vsnwprintf_s(wchar_t* buf, size_t n, size_t, const wchar_t* fmt, va_list a) {
    return vswprintf(buf, n, fmt, a);
}
inline int _vsnprintf_s(char* buf, size_t n, size_t, const char* fmt, va_list a) {
    return vsnprintf(buf, n, fmt, a);
}
inline int _snprintf_s(char* buf, size_t n, size_t, const char* fmt, ...) {
    va_list a; va_start(a, fmt);
    int r = vsnprintf(buf, n, fmt, a);
    va_end(a); return r;
}
inline int _snwprintf_s(wchar_t* buf, size_t n, size_t, const wchar_t* fmt, ...) {
    va_list a; va_start(a, fmt);
    int r = vswprintf(buf, n, fmt, a);
    va_end(a); return r;
}

// Wide-char helpers
#include <wchar.h>
inline int wcsicmp(const wchar_t* a, const wchar_t* b) { return wcscasecmp(a, b); }
inline int _wcsicmp(const wchar_t* a, const wchar_t* b) { return wcscasecmp(a, b); }
inline int _stricmp(const char* a, const char* b) { return strcasecmp(a, b); }

// QueryPerformanceCounter via libogc ticks
#include <ogc/lwp_watchdog.h>
inline bool QueryPerformanceCounter(LARGE_INTEGER* out) {
    out->QuadPart = (long long)gettime();
    return true;
}
inline bool QueryPerformanceFrequency(LARGE_INTEGER* out) {
    out->QuadPart = TB_TIMER_CLOCK * 4; // ~243 MHz bus ticks
    return true;
}

// Thread handle type mapped to LWP thread
#include <ogc/lwp.h>
typedef lwp_t C4JThreadHandle;

// Minimal WCHAR path helpers
inline bool PathFileExistsW(const wchar_t*) { return false; }
inline int  MultiByteToWideChar(int, int, const char* src, int slen,
                                wchar_t* dst, int dlen) {
    if (!dst || dlen == 0) return slen + 1;
    int i = 0;
    while (i < dlen - 1 && src[i]) { dst[i] = (wchar_t)(unsigned char)src[i]; i++; }
    dst[i] = L'\0';
    return i;
}
inline int WideCharToMultiByte(int, int, const wchar_t* src, int,
                               char* dst, int dlen, const char*, bool*) {
    if (!dst || dlen == 0) return 1;
    int i = 0;
    while (i < dlen - 1 && src[i]) { dst[i] = (char)src[i]; i++; }
    dst[i] = '\0';
    return i + 1;
}

// Global memory stat stub
struct MEMORYSTATUS { size_t dwAvailPhys; };
inline void GlobalMemoryStatus(MEMORYSTATUS* ms) { ms->dwAvailPhys = 64 * 1024 * 1024; }

// File I/O stubs (engine uses its own storage layer)
#define GENERIC_READ   0x80000000
#define GENERIC_WRITE  0x40000000
#define FILE_SHARE_READ  1
#define OPEN_EXISTING    3
#define CREATE_ALWAYS    2
#define INVALID_HANDLE_VALUE ((HANDLE)(long long)-1)
inline HANDLE CreateFileW(const wchar_t*, DWORD, DWORD, void*, DWORD, DWORD, void*) {
    return INVALID_HANDLE_VALUE;
}
inline bool CloseHandle(HANDLE) { return true; }
inline bool ReadFile(HANDLE, void*, DWORD, DWORD* r, void*) { if(r)*r=0; return false; }
inline bool WriteFile(HANDLE, const void*, DWORD, DWORD* w, void*) { if(w)*w=0; return false; }
inline DWORD GetFileSize(HANDLE, DWORD*) { return 0; }
inline bool  SetFilePointer(HANDLE, long, void*, DWORD) { return false; }

// Wii has no registry
inline long RegOpenKeyExW(...) { return 1; }
inline long RegQueryValueExW(...) { return 1; }
inline long RegCloseKey(...) { return 0; }

// No networking sockets on Wii (stub — engine has its own QNet)
#ifndef SOCKET
typedef int SOCKET;
#define INVALID_SOCKET ((SOCKET)-1)
#define SOCKET_ERROR   (-1)
#endif

#endif // WII_XBOX_STUBS_H
