#pragma once
#ifndef WII_D3D_STUBS_H
#define WII_D3D_STUBS_H

// ============================================================
// WiiD3DStubs.h
// Minimal D3D/DirectX type aliases for devkitPPC build.
// The engine only uses these as opaque pointers or enums;
// none are ever instantiated on Wii.
// ============================================================

// Basic RECT
typedef struct _RECT {
    long left, top, right, bottom;
} RECT, *PRECT;

// D3D opaque pointer types
typedef void ID3D11Device;
typedef void ID3D11DeviceContext;
typedef void IDXGISwapChain;
typedef RECT D3D11_RECT;
typedef void ID3D11RenderTargetView;
typedef void ID3D11DepthStencilView;
typedef void ID3D11Buffer;
typedef void ID3D11ShaderResourceView;
typedef void ID3D11Resource;
typedef void ID3D11Texture2D;
typedef void D3D11_TEXTURE2D_DESC;

enum D3D11_BLEND {
    D3D11_BLEND_ZERO = 1, D3D11_BLEND_ONE = 2,
    D3D11_BLEND_SRC_COLOR = 3, D3D11_BLEND_INV_SRC_COLOR = 4,
    D3D11_BLEND_SRC_ALPHA = 5, D3D11_BLEND_INV_SRC_ALPHA = 6,
    D3D11_BLEND_DEST_ALPHA = 7, D3D11_BLEND_INV_DEST_ALPHA = 8,
    D3D11_BLEND_DEST_COLOR = 9, D3D11_BLEND_INV_DEST_COLOR = 10,
    D3D11_BLEND_SRC_ALPHA_SAT = 11,
    D3D11_BLEND_BLEND_FACTOR = 14, D3D11_BLEND_INV_BLEND_FACTOR = 15,
};

enum D3D11_COMPARISON_FUNC {
    D3D11_COMPARISON_NEVER = 1, D3D11_COMPARISON_LESS = 2,
    D3D11_COMPARISON_EQUAL = 3, D3D11_COMPARISON_LESS_EQUAL = 4,
    D3D11_COMPARISON_GREATER = 5, D3D11_COMPARISON_NOT_EQUAL = 6,
    D3D11_COMPARISON_GREATER_EQUAL = 7, D3D11_COMPARISON_ALWAYS = 8,
};

// Minimal DirectX math (XMFLOAT*, XMVector*) used by the engine.
// We pull in a lightweight header-only implementation that works on PPC.
#include "../../../Minecraft.Client/Platform/Linux/Stubs/DirectXMath/DirectXMath.h"
using namespace DirectX;

#ifdef __valid
#undef __valid
#endif
#ifdef __notvalid
#undef __notvalid
#endif
#ifdef __maybevalid
#undef __maybevalid
#endif

#endif // WII_D3D_STUBS_H
