#pragma once
#ifndef WII_IGGY_STUBS_H
#define WII_IGGY_STUBS_H

// ============================================================
// WiiIggyStubs.h
// Iggy (Flash/SWF UI) stubs for the Wii build.
// The Wii has no Iggy runtime; all calls are no-ops.
// Mirrors the Linux iggy_stubs.h approach.
// ============================================================

// Pull in the Iggy type definitions without any implementation
#include "../../../Minecraft.Client/Platform/Linux/Iggy/include/iggy.h"

#define STUBBED {}

RADEXPFUNC inline IggyValuePath* RADEXPLINK IggyPlayerRootPath(Iggy*) STUBBED_RET(nullptr)
RADEXPFUNC inline IggyResult     RADEXPLINK IggyPlayerCallMethodRS(Iggy*, IggyDataValue*, IggyValuePath*, IggyName, S32, IggyDataValue*) { return IGGY_RESULT_SUCCESS; }
RADEXPFUNC inline void           RADEXPLINK IggyPlayerDestroy(Iggy*) STUBBED
RADEXPFUNC inline void           RADEXPLINK IggyPlayerSetDisplaySize(Iggy*, S32, S32) STUBBED
RADEXPFUNC inline void           RADEXPLINK IggyPlayerDrawTilesStart(Iggy*) STUBBED
RADEXPFUNC inline void           RADEXPLINK IggyPlayerDrawTile(Iggy*, S32, S32, S32, S32, S32) STUBBED
RADEXPFUNC inline void           RADEXPLINK IggyPlayerDrawTilesEnd(Iggy*) STUBBED

struct FakeIggyPlayer {
    int tickCount;
    IggyProperties props;
    void* userdata;
};
static FakeIggyPlayer s_fakeWiiPlayers[16];
static int s_fakeWiiPlayerCount = 0;

RADEXPFUNC inline Iggy* RADEXPLINK IggyPlayerCreateFromMemory(void const*, U32, IggyPlayerConfig*) {
    if (s_fakeWiiPlayerCount >= 16) return nullptr;
    FakeIggyPlayer* fp = &s_fakeWiiPlayers[s_fakeWiiPlayerCount++];
    fp->tickCount = 0;
    fp->userdata  = nullptr;
    memset(&fp->props, 0, sizeof(fp->props));
    fp->props.movie_width_in_pixels  = 854;
    fp->props.movie_height_in_pixels = 480;
    fp->props.frame_rate = 30.0f;
    return (Iggy*)fp;
}
RADEXPFUNC inline void RADEXPLINK IggyPlayerTick(Iggy* p, float dt) {
    if (p) ((FakeIggyPlayer*)p)->tickCount++;
}
RADEXPFUNC inline IggyProperties* RADEXPLINK IggyPlayerGetProperties(Iggy* p) {
    return p ? &((FakeIggyPlayer*)p)->props : nullptr;
}
RADEXPFUNC inline IggyResult RADEXPLINK IggyPlayerGetVariable(Iggy*, IggyValuePath*, IggyDataValue*) { return IGGY_RESULT_SUCCESS; }
RADEXPFUNC inline IggyResult RADEXPLINK IggyPlayerSetVariable(Iggy*, IggyValuePath*, IggyDataValue*) { return IGGY_RESULT_SUCCESS; }
RADEXPFUNC inline IggyResult RADEXPLINK IggyNameFromString(IggyName*, const char*, U32) { return IGGY_RESULT_SUCCESS; }
RADEXPFUNC inline IggyResult RADEXPLINK IggyValuePathFromRoot(IggyValuePath**, Iggy*) { return IGGY_RESULT_SUCCESS; }
RADEXPFUNC inline void RADEXPLINK IggyValuePathDestroy(IggyValuePath*) STUBBED
RADEXPFUNC inline void RADEXPLINK IggyDataValueInit(IggyDataValue*) STUBBED
RADEXPFUNC inline void RADEXPLINK IggyDataValueDestroy(IggyDataValue*) STUBBED
RADEXPFUNC inline bool RADEXPLINK IggyInit(IggyConfig*) { return true; }
RADEXPFUNC inline void RADEXPLINK IggyShutdown() STUBBED

// GDraw (rendering backend for Iggy) — all stubs on Wii
typedef void GDrawContext;
typedef void GDrawTexture;
typedef void GDrawFont;
inline GDrawContext* GDrawContextCreate(void*, int, int) { return nullptr; }
inline void GDrawContextDestroy(GDrawContext*) {}
inline void GDrawContextSetSize(GDrawContext*, int, int) {}
inline void GDrawBeginFrame(GDrawContext*) {}
inline void GDrawEndFrame(GDrawContext*) {}
inline void GDrawSetBlendMode(GDrawContext*, int) {}

#undef STUBBED

#endif // WII_IGGY_STUBS_H
