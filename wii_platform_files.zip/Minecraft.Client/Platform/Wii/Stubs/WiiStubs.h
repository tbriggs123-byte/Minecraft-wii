#pragma once
#ifndef WII_STUBS_H
#define WII_STUBS_H

// ============================================================
// WiiStubs.h
// Provides Windows/Linux type aliases and minimal API stubs
// for the devkitPPC / libogc toolchain.
// ============================================================

#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cstdarg>
#include <cassert>
#include <cmath>
#include <string>
#include <climits>
#include <cfloat>

// libogc threading
#include <ogc/lwp.h>
#include <ogc/mutex.h>
#include <ogc/cond.h>
#include <ogc/lwp_watchdog.h>   // gettime() / ticks_to_millisecs()
#include <unistd.h>

// ---- Windows primitive aliases ----
#define TRUE  true
#define FALSE false

typedef bool                BOOL;
typedef BOOL*               PBOOL;
typedef BOOL*               LPBOOL;
typedef unsigned int        DWORD;
typedef DWORD*              PDWORD;
typedef DWORD*              LPDWORD;
typedef void*               LPVOID;
typedef const void*         LPCVOID;
typedef wchar_t             WCHAR;
typedef wchar_t*            LPWSTR;
typedef wchar_t*            PWSTR;
typedef const wchar_t*      LPCWSTR;
typedef unsigned char       BYTE;
typedef BYTE*               PBYTE;
typedef unsigned long long  ULONGLONG;
typedef int                 HRESULT;
typedef unsigned int        UINT;
typedef void*               HANDLE;
typedef int                 INT;
typedef long*               PLONG;
typedef const void*         LPCVOID2;
typedef char                CHAR;
typedef void*               PVOID;
typedef uintptr_t           ULONG_PTR;
typedef long                LONG;
typedef long                LONG64;
typedef long*               PLONG64;
typedef void                VOID;
typedef ULONGLONG           PlayerUID;
typedef DWORD               WORD;
typedef unsigned char       boolean;
typedef long long           LONGLONG;
typedef size_t              SIZE_T;
typedef short               SHORT;
typedef float               FLOAT;
typedef unsigned long       ULONG;
typedef int64_t             __int64;
typedef uint64_t            __uint64;
typedef int                 __int32;

#define CONST const
#define WINAPI
#define __cdecl
#define __debugbreak()

#define S_OK    0
#define S_FALSE ((HRESULT)0x00000001L)

#define ERROR_SUCCESS    0L
#define ERROR_IO_PENDING 997L
#define ERROR_CANCELLED  1223L
#define INFINITE         0xFFFFFFFF

#define FAILED(hr)   ((hr) < 0)
#define SUCCEEDED(hr) ((hr) >= 0)
#define HRESULT_SUCCEEDED(hr) SUCCEEDED(hr)

#define RtlZeroMemory(dst,len) memset((dst),0,(len))
#define ZeroMemory RtlZeroMemory

typedef struct { DWORD LowPart; LONG HighPart; long long QuadPart; } LARGE_INTEGER;
typedef struct { DWORD LowPart; LONG HighPart; long long QuadPart; } ULARGE_INTEGER;

// ---- CRITICAL_SECTION (mapped to libogc mutex) ----
typedef mutex_t CRITICAL_SECTION;
inline void InitializeCriticalSection(CRITICAL_SECTION* cs) { LWP_MutexInit(cs, false); }
inline void DeleteCriticalSection(CRITICAL_SECTION* cs)     { LWP_MutexDestroy(*cs); }
inline void EnterCriticalSection(CRITICAL_SECTION* cs)      { LWP_MutexLock(*cs); }
inline void LeaveCriticalSection(CRITICAL_SECTION* cs)      { LWP_MutexUnlock(*cs); }

// ---- TLS (fake via a simple global slot array — single-threaded for Wii) ----
// Wii has at most a handful of threads so we use a small fixed table.
#define TLS_SLOTS 64
static void* g_tlsSlots[TLS_SLOTS] = {};
static int   g_tlsNext = 0;
typedef int  DWORD_TLS;
inline DWORD TlsAlloc()                     { return (DWORD)(g_tlsNext < TLS_SLOTS ? g_tlsNext++ : -1); }
inline void* TlsGetValue(DWORD idx)         { return (idx < TLS_SLOTS) ? g_tlsSlots[idx] : nullptr; }
inline bool  TlsSetValue(DWORD idx, void* v){ if (idx < TLS_SLOTS) { g_tlsSlots[idx] = v; return true; } return false; }
inline bool  TlsFree(DWORD)                 { return true; }

// ---- Sleep ----
inline void Sleep(DWORD ms) { usleep((useconds_t)ms * 1000u); }

// ---- Wii doesn't have PIX ----
inline void PIXBeginNamedEvent(int, const char*, ...) {}
inline void PIXEndNamedEvent()                         {}
inline void PIXAddNamedCounter(float, const char*, ...) {}
inline void PIXSetMarkerDeprecated(int, const char*, ...) {}

// ---- D3D / HRESULT stubs needed by engine headers ----
#include "WiiD3DStubs.h"

// ---- Xbox / title-specific stubs ----
#include "WiiXboxStubs.h"

// ---- Iggy (Flash UI) stubs — Wii has no Iggy ----
#include "WiiIggyStubs.h"

#endif // WII_STUBS_H
