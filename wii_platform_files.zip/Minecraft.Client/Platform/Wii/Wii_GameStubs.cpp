// ============================================================
// Wii_GameStubs.cpp
// Platform stubs for the Wii build.
// Mirrors linux_game_stubs.cpp.
// ============================================================

#include <cstddef>
#include <cstring>
#include <string>
#include <ogc/lwp.h>

#include "Stubs/WiiStubs.h"
#include "../Common/Consoles_App.h"

// Display::update — no-op on Wii (GX handles vsync in Present)
void Display::update() {}

// GetTPConfigVal — texture pack config; not supported on Wii
int CMinecraftApp::GetTPConfigVal(WCHAR*) { return 0; }

// PIX performance markers — no-op on Wii
void PIXSetMarkerDeprecated(int, const char*, ...) {}

// NetworkPlayerXbox stubs (engine expects these symbols)
#include "../Xbox/Network/NetworkPlayerXbox.h"

NetworkPlayerXbox::NetworkPlayerXbox(IQNetPlayer* p)
    : m_qnetPlayer(p), m_pSocket(nullptr) {}
IQNetPlayer* NetworkPlayerXbox::GetQNetPlayer() { return m_qnetPlayer; }
unsigned char NetworkPlayerXbox::GetSmallId() { return 0; }
void NetworkPlayerXbox::SendData(INetworkPlayer*, const void*, int, bool) {}
bool NetworkPlayerXbox::IsSameSystem(INetworkPlayer*) { return false; }
int  NetworkPlayerXbox::GetSendQueueSizeBytes(INetworkPlayer*, bool) { return 0; }
int  NetworkPlayerXbox::GetSendQueueSizeMessages(INetworkPlayer*, bool) { return 0; }
int  NetworkPlayerXbox::GetCurrentRtt() { return 0; }
bool NetworkPlayerXbox::IsHost() { return false; }
bool NetworkPlayerXbox::IsGuest() { return false; }
bool NetworkPlayerXbox::IsLocal() { return true; }
int  NetworkPlayerXbox::GetSessionIndex() { return 0; }
bool NetworkPlayerXbox::IsTalking() { return false; }
bool NetworkPlayerXbox::IsMutedByLocalUser(int) { return false; }
bool NetworkPlayerXbox::HasVoice() { return false; }
bool NetworkPlayerXbox::HasCamera() { return false; }
int  NetworkPlayerXbox::GetUserIndex() { return 0; }
void NetworkPlayerXbox::SetSocket(Socket* s) { m_pSocket = s; }
Socket* NetworkPlayerXbox::GetSocket() { return m_pSocket; }
const wchar_t* NetworkPlayerXbox::GetOnlineName() { return L"Player"; }
std::wstring NetworkPlayerXbox::GetDisplayName() { return L"Player"; }
PlayerUID NetworkPlayerXbox::GetUID() { return PlayerUID(); }

// ShutdownManager (PS3 implementation; Wii version is all no-ops)
#include "../PS3/PS3Extras/ShutdownManager.h"
void ShutdownManager::Initialise() {}
void ShutdownManager::StartShutdown() {}
void ShutdownManager::MainThreadHandleShutdown() {}
void ShutdownManager::HasStarted(ShutdownManager::EThreadId) {}
void ShutdownManager::HasStarted(ShutdownManager::EThreadId, C4JThread::EventArray*) {}
bool ShutdownManager::ShouldRun(ShutdownManager::EThreadId) { return true; }
void ShutdownManager::HasFinished(ShutdownManager::EThreadId) {}

// Rich-presence string helpers (no-op on Wii)
#include <vector>
static std::vector<uint8_t*> vRichPresenceStrings;
uint8_t* AddRichPresenceString(int) { return nullptr; }
void FreeRichPresenceStrings() { vRichPresenceStrings.clear(); }

// extraX64.h defines a few x86-64-specific helpers; pull them in
// via the platform header so they resolve to no-ops on PPC.
#include "../../../Minecraft.World/Platform/x64headers/extraX64.h"
