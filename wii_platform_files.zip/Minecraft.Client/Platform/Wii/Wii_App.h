#pragma once
// ============================================================
// Wii_App.h
// Wii concrete implementation of CMinecraftApp.
// ============================================================

#include "../Common/Consoles_App.h"

class CWiiMinecraftApp : public CMinecraftApp {
public:
    CWiiMinecraftApp();

    // --- Rich presence (no-op on Wii) ---
    virtual void SetRichPresenceContext(int iPad, int contextId);

    // --- Launch / lifecycle ---
    virtual void StoreLaunchData()  {}
    virtual void ExitGame();
    virtual void FatalLoadError();

    // --- Save thumbnails (Wii has no social screenshot sharing) ---
    virtual void CaptureSaveThumbnail()                                   {}
    virtual void GetSaveThumbnail(std::uint8_t**, unsigned int*)          {}
    virtual void ReleaseSaveThumbnail()                                   {}
    virtual void GetScreenshot(int, std::uint8_t**, unsigned int*)        {}

    // --- TMS (title-managed storage) not available on Wii ---
    virtual int  LoadLocalTMSFile(WCHAR*)                                 { return -1; }
    virtual int  LoadLocalTMSFile(WCHAR*, eFileExtensionType)             { return -1; }
    virtual void FreeLocalTMSFiles(eTMSFileType)                          {}
    virtual int  GetLocalTMSFileIndex(WCHAR*, bool, eFileExtensionType =
                                      eFileExtensionType_PNG)             { return -1; }

    // --- Banned list (no online on Wii) ---
    virtual void ReadBannedList(int, eTMSAction = (eTMSAction)0, bool = false) {}

    // --- String table ---
    C4JStringTable* GetStringTable() { return nullptr; }

    // --- Debug boot: directly start a world without UI ---
    virtual void TemporaryCreateGameStart();
};

extern CWiiMinecraftApp app;
