#pragma once
// ============================================================
// Wii_UIController.h
// Stub UI controller — Wii has no Iggy/Flash runtime.
// ============================================================
#include "../Common/UI/UIController.h"

class WiiUIController : public UIController {
public:
    void init(S32 w, S32 h) override {}
    void render() override {}
    void beginIggyCustomDraw4J(IggyCustomDrawCallbackRegion*, CustomDrawData*) {}
    virtual CustomDrawData* setupCustomDraw(UIScene*, IggyCustomDrawCallbackRegion*) { return nullptr; }
    virtual CustomDrawData* calculateCustomDraw(IggyCustomDrawCallbackRegion*) { return nullptr; }
    virtual void endCustomDraw(IggyCustomDrawCallbackRegion*) {}

protected:
    virtual void setTileOrigin(S32, S32) {}

public:
    GDrawTexture* getSubstitutionTexture(int)    { return nullptr; }
    void destroySubstitutionTexture(void*, GDrawTexture*) {}
    void shutdown() {}
};

extern WiiUIController ui;
