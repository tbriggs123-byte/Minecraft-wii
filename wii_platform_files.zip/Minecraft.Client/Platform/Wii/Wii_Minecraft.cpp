// ============================================================
// Wii_Minecraft.cpp
// Entry point for the Wii build.
// Mirrors Linux_Minecraft.cpp but uses WPAD / libogc instead
// of SDL2 / pthreads for all platform services.
// ============================================================

#include "../../../Minecraft.World/Platform/stdafx.h"

// libogc
#include <ogc/system.h>
#include <ogc/lwp.h>
#include <wiiuse/wpad.h>
#include <fat.h>       // SD card / USB filesystem

#include <cstdio>
#include <cstring>
#include <cassert>

// Engine headers
#include "../Windows64/GameConfig/Minecraft.spa.h"
#include "../../MinecraftServer.h"
#include "../../Player/LocalPlayer.h"
#include "../../../Minecraft.World/Items/ItemInstance.h"
#include "../../../Minecraft.World/Util/Language.h"
#include "../../../Minecraft.World/Util/AABB.h"
#include "../../../Minecraft.World/Util/Vec3.h"
#include "../../../Minecraft.World/Level/Level.h"
#include "../../Network/ClientConnection.h"
#include "../../Player/User.h"
#include "../../Rendering/Tesselator.h"
#include "../../GameState/Options.h"
#include "../Orbis/Sentient/SentientManager.h"
#include "../../../Minecraft.World/Util/IntCache.h"
#include "../../Textures/Textures.h"
#include "../../../Minecraft.World/IO/Streams/Compression.h"
#include "../../../Minecraft.World/Level/Storage/OldChunkStorage.h"
#include "../../../Minecraft.World/Headers/net.minecraft.world.level.tile.h"

// Wii platform layer
#include "Wii_App.h"
#include "Wii_Render.h"
#include "Wii_UIController.h"

// ------------------------------------------------------------------
// Globals
// ------------------------------------------------------------------
bool g_wiiShouldExit = false;  // set by Home button handler in Wii_Input

WiiUIController ui;

// Profile/storage sizes (same as Linux build)
#define FIFTY_ONE_MB (1000000 * 51)

DWORD dwProfileSettingsA[5] = { 0, 0, 0, 0, 0 };
static const int NUM_PROFILE_VALUES  = 5;
static const int NUM_PROFILE_SETTINGS = 4;

// ------------------------------------------------------------------
// Controller action bindings — identical to Linux_Minecraft.cpp
// (DefineActions) but called after InputManager.Initialise
// ------------------------------------------------------------------
static void DefineActions() {
    // Menu actions
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_A,              _360_JOY_BUTTON_A);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_B,              _360_JOY_BUTTON_B);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_X,              _360_JOY_BUTTON_X);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_Y,              _360_JOY_BUTTON_Y);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_OK,             _360_JOY_BUTTON_A);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_CANCEL,         _360_JOY_BUTTON_B);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_UP,
        _360_JOY_BUTTON_DPAD_UP    | _360_JOY_BUTTON_LSTICK_UP);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_DOWN,
        _360_JOY_BUTTON_DPAD_DOWN  | _360_JOY_BUTTON_LSTICK_DOWN);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_LEFT,
        _360_JOY_BUTTON_DPAD_LEFT  | _360_JOY_BUTTON_LSTICK_LEFT);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_RIGHT,
        _360_JOY_BUTTON_DPAD_RIGHT | _360_JOY_BUTTON_LSTICK_RIGHT);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_PAGEUP,         _360_JOY_BUTTON_LT);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_PAGEDOWN,       _360_JOY_BUTTON_RT);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_RIGHT_SCROLL,   _360_JOY_BUTTON_RB);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_LEFT_SCROLL,    _360_JOY_BUTTON_LB);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_PAUSEMENU,      _360_JOY_BUTTON_START);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_STICK_PRESS,    _360_JOY_BUTTON_LTHUMB);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_OTHER_STICK_PRESS, _360_JOY_BUTTON_RTHUMB);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_OTHER_STICK_UP,    _360_JOY_BUTTON_RSTICK_UP);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_OTHER_STICK_DOWN,  _360_JOY_BUTTON_RSTICK_DOWN);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_OTHER_STICK_LEFT,  _360_JOY_BUTTON_RSTICK_LEFT);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, ACTION_MENU_OTHER_STICK_RIGHT, _360_JOY_BUTTON_RSTICK_RIGHT);

    // In-game actions
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_JUMP,          _360_JOY_BUTTON_A);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_FORWARD,       _360_JOY_BUTTON_LSTICK_UP);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_BACKWARD,      _360_JOY_BUTTON_LSTICK_DOWN);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_LEFT,          _360_JOY_BUTTON_LSTICK_LEFT);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_RIGHT,         _360_JOY_BUTTON_LSTICK_RIGHT);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_LOOK_LEFT,     _360_JOY_BUTTON_RSTICK_LEFT);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_LOOK_RIGHT,    _360_JOY_BUTTON_RSTICK_RIGHT);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_LOOK_UP,       _360_JOY_BUTTON_RSTICK_UP);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_LOOK_DOWN,     _360_JOY_BUTTON_RSTICK_DOWN);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_USE,           _360_JOY_BUTTON_LT);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_ACTION,        _360_JOY_BUTTON_RT);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_RIGHT_SCROLL,  _360_JOY_BUTTON_RB);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_LEFT_SCROLL,   _360_JOY_BUTTON_LB);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_INVENTORY,     _360_JOY_BUTTON_Y);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_PAUSEMENU,     _360_JOY_BUTTON_START);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_DROP,          _360_JOY_BUTTON_B);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_SNEAK_TOGGLE,  _360_JOY_BUTTON_RTHUMB);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_CRAFTING,      _360_JOY_BUTTON_X);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_RENDER_THIRD_PERSON, _360_JOY_BUTTON_LTHUMB);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_GAME_INFO,     _360_JOY_BUTTON_BACK);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_DPAD_LEFT,     _360_JOY_BUTTON_DPAD_LEFT);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_DPAD_RIGHT,    _360_JOY_BUTTON_DPAD_RIGHT);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_DPAD_UP,       _360_JOY_BUTTON_DPAD_UP);
    InputManager.SetGameJoypadMaps(MAP_STYLE_0, MINECRAFT_ACTION_DPAD_DOWN,     _360_JOY_BUTTON_DPAD_DOWN);
}

// ------------------------------------------------------------------
// Minecraft start thread (mirrors Linux_Minecraft.cpp)
// ------------------------------------------------------------------
static int StartMinecraftThreadProc(void* lpParameter) {
    Vec3::UseDefaultThreadStorage();
    AABB::UseDefaultThreadStorage();
    Tesselator::CreateNewThreadStorage(512 * 1024); // Wii has 64MB RAM; be conservative
    RenderManager.InitialiseContext();
    Minecraft::start(std::wstring(), std::wstring());
    delete Tesselator::getInstance();
    return 0;
}

// ------------------------------------------------------------------
// main()
// ------------------------------------------------------------------
int main(int, char**) {
    // ---- libogc initialisation ----
    SYS_Init();

    // ---- FAT / SD card (needed for save files) ----
    if (!fatInitDefault()) {
        printf("[Wii] fatInitDefault failed — saves will not work\n");
    }

    // ---- Render ----
    RenderManager.Initialise();

    app.DebugPrintf("---main()\n");

    // ---- Media / string table ----
    app.loadMediaArchive();
    app.loadStringTable();

    // ---- UI (stub — no Iggy on Wii) ----
    ui.init(640, 480);

    // ---- Storage ----
    StorageManager.Init(0, app.GetString(IDS_DEFAULT_SAVENAME),
                        (char*)"savegame.dat", FIFTY_ONE_MB,
                        &CConsoleMinecraftApp::DisplaySavingMessage,
                        (LPVOID)&app, (char*)"sd:/minecraft/");

    // ---- Time ----
    app.InitTime();

    // ---- Input ----
    InputManager.Initialise(1, MAX_MAPS, MINECRAFT_ACTION_MAX, ACTION_MAX_MENU);
    DefineActions();
    InputManager.SetJoypadMapVal(0, 0);
    InputManager.SetKeyRepeatRate(0.3f, 0.2f);

    // ---- Profile manager ----
    ProfileManager.Initialise(
        TITLEID_MINECRAFT, app.m_dwOfferID, PROFILE_VERSION_10,
        NUM_PROFILE_VALUES, NUM_PROFILE_SETTINGS, dwProfileSettingsA,
        app.GAME_DEFINED_PROFILE_DATA_BYTES * XUSER_MAX_COUNT,
        &app.uiGameDefinedDataChangedBitmask);
    ProfileManager.SetSignInChangeCallback(
        &CConsoleMinecraftApp::SignInChangeCallback, &app);

    // ---- Network manager ----
    g_NetworkManager.Initialise();
    ProfileManager.SetDebugFullOverride(true);

    // ---- TLS pools ----
    Tesselator::CreateNewThreadStorage(512 * 1024);
    AABB::CreateNewThreadStorage();
    Vec3::CreateNewThreadStorage();
    IntCache::CreateNewThreadStorage();
    Compression::CreateNewThreadStorage();
    OldChunkStorage::CreateNewThreadStorage();
    Level::enableLightingCache();
    Tile::CreateNewThreadStorage();

    // ---- Minecraft::main() ----
    Minecraft::main();

    // ---- Spin up the Minecraft start thread ----
    C4JThread* minecraftThread = new C4JThread(
        &StartMinecraftThreadProc, nullptr, "RunningMinecraftStart");
    minecraftThread->Run();

    // Boot loop: render frames while start thread is running
    do {
        RenderManager.StartFrame();
        Sleep(20);
        RenderManager.Present();
    } while (minecraftThread->isRunning());
    delete minecraftThread;

    // Re-acquire GL context on the main thread
    RenderManager.InitialiseContext();

    Minecraft* pMinecraft = Minecraft::GetInstance();
    app.InitGameSettings();
    app.InitialiseTips();

    // ------------------------------------------------------------------
    // Main game loop
    // ------------------------------------------------------------------
    while (!g_wiiShouldExit && !RenderManager.ShouldClose()) {
        RenderManager.StartFrame();

        app.UpdateTime();
        InputManager.Tick();
        ProfileManager.Tick();
        StorageManager.Tick();
        RenderManager.Tick();

        g_NetworkManager.DoWork();

        if (app.GetGameStarted()) {
            pMinecraft->run_middle();
            app.SetAppPaused(
                g_NetworkManager.IsLocalGame() &&
                g_NetworkManager.GetPlayerCount() == 1 &&
                ui.IsPauseMenuDisplayed(ProfileManager.GetPrimaryPad()));
        } else {
            pMinecraft->soundEngine->tick(nullptr, 0.0f);
            pMinecraft->textures->tick(true, false);
            IntCache::Reset();
            if (app.GetReallyChangingSessionType())
                pMinecraft->tickAllConnections();
        }

        pMinecraft->soundEngine->playMusicTick();

        // UI tick/render (stub on Wii — no Flash)
        ui.tick();
        ui.render();

        // Present
        RenderManager.Present();

        // Profile data change
        if (app.uiGameDefinedDataChangedBitmask != 0) {
            void* pData;
            for (int i = 0; i < XUSER_MAX_COUNT; i++) {
                if (app.uiGameDefinedDataChangedBitmask & (1 << i)) {
                    app.ClearGameSettingsChangedFlag(i);
                    app.ApplyGameSettingsChanged(i);
                    pMinecraft->stats[i]->clear();
                    pMinecraft->stats[i]->parse(pData);
                }
            }
            app.uiGameDefinedDataChangedBitmask = 0;
        }

        g_NetworkManager.DoWork();
        app.HandleXuiActions();
        Vec3::resetPool();
    }

    // ---- Graceful shutdown ----
    RenderManager.Shutdown();

    // Return to Homebrew Channel / loader
    return 0;
}
