// ============================================================
// Wii_Input.cpp
// C_4JInput implementation for Wii using WPAD (Wiimote + Nunchuk).
//
// Controller mapping (Wiimote held sideways + Nunchuk):
//
//   Wiimote (sideways)        → Xbox 360 equivalent
//   ─────────────────────────────────────────────────
//   A (face, right thumb)     → A
//   B (trigger)               → Right Trigger (RT / action)
//   1                         → B
//   2                         → X
//   +                         → Start
//   -                         → Back
//   Home                      → (exit)
//   D-Pad Up/Down/Left/Right  → D-Pad
//   Nunchuk C                 → Left Bumper (LB)
//   Nunchuk Z                 → Left Trigger (LT / use)
//   Nunchuk stick             → Left stick (movement)
//   Wiimote IR                → Right stick (look) — gyro fallback
// ============================================================

#include "../../../4J.Input/4J_Input.h"
#include "../Common/App_enums.h"
#include "../../../4J.Render/4J_Render.h"

#include <wiiuse/wpad.h>
#include <ogc/lwp_watchdog.h>
#include <cstring>
#include <cmath>
#include <cstdio>

// ------------------------------------------------------------------
// Singleton (defined by the engine linker; declared in 4J_Input.h)
// ------------------------------------------------------------------
C_4JInput InputManager;

// ------------------------------------------------------------------
// State
// ------------------------------------------------------------------
namespace {

static const int MAX_PADS = 4;

// Per-pad digital button bitmask (engine _360_JOY_BUTTON_* format)
static unsigned int s_btnCurrent[MAX_PADS] = {};
static unsigned int s_btnPrev[MAX_PADS]    = {};

// Per-pad analog sticks
static float s_lx[MAX_PADS] = {}, s_ly[MAX_PADS] = {};
static float s_rx[MAX_PADS] = {}, s_ry[MAX_PADS] = {};
static uint8_t s_lt[MAX_PADS] = {}, s_rt[MAX_PADS] = {};

// Menu-displayed flags
static bool s_menuDisplayed[MAX_PADS] = {};

// Scroll wheel (no scroll wheel on Wii — kept at 0)
static int s_scrollSnap = 0;

// Action map: ucMap × ucAction → engine button bitmask
static const int MAX_MAPS    = 3;
static const int MAX_ACTIONS = 64;
static unsigned int s_actionMap[MAX_MAPS][MAX_ACTIONS] = {};

// Per-pad map selection
static uint8_t s_padMap[MAX_PADS] = {};

// Key-repeat state (unused on Wii — controller has no key repeat)
static float s_repeatDelay = 0.3f;
static float s_repeatRate  = 0.2f;

// Deadzone for Nunchuk stick (0..128)
static const float STICK_DEADZONE = 0.15f;

// IR-based look sensitivity (pixels → normalised delta)
static const float IR_SCALE = 0.003f;

// Previous IR position for delta computation
static float s_irPrevX[MAX_PADS] = { -1, -1, -1, -1 };
static float s_irPrevY[MAX_PADS] = { -1, -1, -1, -1 };

// ------------------------------------------------------------------
// Map a normalised stick value through deadzone
// ------------------------------------------------------------------
static float applyDeadzone(float v) {
    if (v >  STICK_DEADZONE) return (v - STICK_DEADZONE) / (1.0f - STICK_DEADZONE);
    if (v < -STICK_DEADZONE) return (v + STICK_DEADZONE) / (1.0f - STICK_DEADZONE);
    return 0.0f;
}

// ------------------------------------------------------------------
// Convert WPAD data for one controller slot into engine bitmask
// ------------------------------------------------------------------
static void updatePad(int p) {
    WPADData* d = WPAD_Data(p);
    if (!d || d->err != WPAD_ERR_NONE) {
        s_btnCurrent[p] = 0;
        s_lx[p] = s_ly[p] = s_rx[p] = s_ry[p] = 0;
        s_lt[p] = s_rt[p] = 0;
        return;
    }

    uint32_t held = d->btns_h; // currently held buttons (WPAD_BUTTON_*)

    unsigned int bits = 0;

    // ---- Face buttons ----
    // We treat the Wiimote held horizontally (Classic-lite layout) or with
    // Nunchuk. Buttons: 2=A, 1=B, +=Start, -=Back, Home=exit
    if (held & WPAD_BUTTON_A)     bits |= _360_JOY_BUTTON_A;
    if (held & WPAD_BUTTON_B)     bits |= _360_JOY_BUTTON_RT;  // trigger = action
    if (held & WPAD_BUTTON_1)     bits |= _360_JOY_BUTTON_B;
    if (held & WPAD_BUTTON_2)     bits |= _360_JOY_BUTTON_X;
    if (held & WPAD_BUTTON_PLUS)  bits |= _360_JOY_BUTTON_START;
    if (held & WPAD_BUTTON_MINUS) bits |= _360_JOY_BUTTON_BACK;

    // ---- D-Pad (Wiimote held sideways maps 1:1) ----
    if (held & WPAD_BUTTON_UP)    bits |= _360_JOY_BUTTON_DPAD_UP;
    if (held & WPAD_BUTTON_DOWN)  bits |= _360_JOY_BUTTON_DPAD_DOWN;
    if (held & WPAD_BUTTON_LEFT)  bits |= _360_JOY_BUTTON_DPAD_LEFT;
    if (held & WPAD_BUTTON_RIGHT) bits |= _360_JOY_BUTTON_DPAD_RIGHT;

    // ---- Nunchuk buttons ----
    if (d->exp.type == WPAD_EXP_NUNCHUK) {
        struct nunchuk_t* nc = &d->exp.nunchuk;
        if (held & WPAD_NUNCHUK_BUTTON_C) bits |= _360_JOY_BUTTON_LB;
        if (held & WPAD_NUNCHUK_BUTTON_Z) bits |= _360_JOY_BUTTON_LT;

        // Left stick (Nunchuk joystick)
        float nx = (nc->js.pos.x - nc->js.center.x) / 100.0f;
        float ny = (nc->js.pos.y - nc->js.center.y) / 100.0f;
        // Clamp
        if (nx >  1.0f) nx =  1.0f; if (nx < -1.0f) nx = -1.0f;
        if (ny >  1.0f) ny =  1.0f; if (ny < -1.0f) ny = -1.0f;
        s_lx[p] = applyDeadzone(nx);
        s_ly[p] = applyDeadzone(-ny); // Y is inverted vs engine convention

        // Synthesize digital stick buttons for movement
        if (s_lx[p] >  0.5f) bits |= _360_JOY_BUTTON_LSTICK_RIGHT;
        if (s_lx[p] < -0.5f) bits |= _360_JOY_BUTTON_LSTICK_LEFT;
        if (s_ly[p] >  0.5f) bits |= _360_JOY_BUTTON_LSTICK_UP;
        if (s_ly[p] < -0.5f) bits |= _360_JOY_BUTTON_LSTICK_DOWN;

        s_lt[p] = (bits & _360_JOY_BUTTON_LT) ? 255 : 0;
        s_rt[p] = (bits & _360_JOY_BUTTON_RT) ? 255 : 0;
    } else {
        s_lx[p] = s_ly[p] = 0;
        s_lt[p] = s_rt[p] = 0;
    }

    // ---- IR pointer → right stick (look) ----
    // IR gives screen-space position; we compute a delta vs last frame.
    if (d->ir.valid) {
        float irX = d->ir.x / 640.0f;  // normalise to [0,1]
        float irY = d->ir.y / 480.0f;
        if (s_irPrevX[p] < 0) {
            // First valid frame — seed without a delta
            s_irPrevX[p] = irX;
            s_irPrevY[p] = irY;
            s_rx[p] = s_ry[p] = 0;
        } else {
            float dx = (irX - s_irPrevX[p]) / IR_SCALE;
            float dy = (irY - s_irPrevY[p]) / IR_SCALE;
            s_irPrevX[p] = irX;
            s_irPrevY[p] = irY;
            // Clamp to [-1,1]
            s_rx[p] = dx >  1.0f ?  1.0f : dx < -1.0f ? -1.0f : dx;
            s_ry[p] = dy >  1.0f ?  1.0f : dy < -1.0f ? -1.0f : dy;
        }

        // Synthesize digital look buttons
        if (s_rx[p] >  0.4f) bits |= _360_JOY_BUTTON_RSTICK_RIGHT;
        if (s_rx[p] < -0.4f) bits |= _360_JOY_BUTTON_RSTICK_LEFT;
        if (s_ry[p] >  0.4f) bits |= _360_JOY_BUTTON_RSTICK_DOWN;
        if (s_ry[p] < -0.4f) bits |= _360_JOY_BUTTON_RSTICK_UP;
    } else {
        s_irPrevX[p] = -1; s_irPrevY[p] = -1;
        s_rx[p] = s_ry[p] = 0;
    }

    s_btnCurrent[p] = bits;
}

// ------------------------------------------------------------------
// Resolve an action to the raw engine button bitmask for this pad
// ------------------------------------------------------------------
static unsigned int actionBits(int iPad, unsigned char ucAction) {
    if (iPad < 0 || iPad >= MAX_PADS) return 0;
    uint8_t map = s_padMap[iPad];
    if (map >= MAX_MAPS || ucAction >= MAX_ACTIONS) return 0;
    return s_actionMap[map][ucAction];
}

} // namespace

// ==================================================================
// C_4JInput public API
// ==================================================================

void C_4JInput::Initialise(int, unsigned char, unsigned char, unsigned char) {
    WPAD_Init();
    // Enable IR + Nunchuk for all four pads
    for (int i = 0; i < MAX_PADS; i++) {
        WPAD_SetDataFormat(i, WPAD_FMT_BTNS_ACC_IR);
        WPAD_SetVRes(i, 640, 480);
    }
    memset(s_btnCurrent, 0, sizeof(s_btnCurrent));
    memset(s_btnPrev,    0, sizeof(s_btnPrev));
    memset(s_actionMap,  0, sizeof(s_actionMap));
    memset(s_padMap,     0, sizeof(s_padMap));
    memset(s_menuDisplayed, 0, sizeof(s_menuDisplayed));
    printf("[Wii_Input] WPAD initialised\n");
}

void C_4JInput::Tick() {
    WPAD_ScanPads();

    for (int p = 0; p < MAX_PADS; p++) {
        s_btnPrev[p] = s_btnCurrent[p];
        updatePad(p);
    }
    s_scrollSnap = 0;

    // Home button → signal shutdown
    for (int p = 0; p < MAX_PADS; p++) {
        if (WPAD_Data(p) && (WPAD_Data(p)->btns_d & WPAD_BUTTON_HOME)) {
            extern bool g_wiiShouldExit;
            g_wiiShouldExit = true;
        }
    }
}

void C_4JInput::SetDeadzoneAndMovementRange(unsigned int, unsigned int) {}

void C_4JInput::SetGameJoypadMaps(unsigned char ucMap, unsigned char ucAction,
                                   unsigned int uiActionVal) {
    if (ucMap < MAX_MAPS && ucAction < MAX_ACTIONS)
        s_actionMap[ucMap][ucAction] = uiActionVal;
}

unsigned int C_4JInput::GetGameJoypadMaps(unsigned char ucMap, unsigned char ucAction) {
    if (ucMap < MAX_MAPS && ucAction < MAX_ACTIONS)
        return s_actionMap[ucMap][ucAction];
    return 0;
}

void C_4JInput::SetJoypadMapVal(int iPad, unsigned char ucMap) {
    if (iPad >= 0 && iPad < MAX_PADS) s_padMap[iPad] = ucMap;
}

unsigned char C_4JInput::GetJoypadMapVal(int iPad) {
    return (iPad >= 0 && iPad < MAX_PADS) ? s_padMap[iPad] : 0;
}

void C_4JInput::SetJoypadSensitivity(int, float) {}
void C_4JInput::SetKeyRepeatRate(float d, float r) { s_repeatDelay=d; s_repeatRate=r; }
void C_4JInput::SetDebugSequence(const char*, int(*)(void*), void*) {}
void C_4JInput::SetJoypadStickAxisMap(int, unsigned int, unsigned int) {}
void C_4JInput::SetJoypadStickTriggerMap(int, unsigned int, unsigned int) {}
void C_4JInput::SetMenuDisplayed(int iPad, bool val) {
    if (iPad >= 0 && iPad < MAX_PADS) s_menuDisplayed[iPad] = val;
}

float C_4JInput::GetIdleSeconds(int) { return 0.0f; }
bool  C_4JInput::IsPadConnected(int iPad) {
    if (iPad < 0 || iPad >= MAX_PADS) return false;
    uint32_t type;
    return WPAD_Probe(iPad, &type) == WPAD_ERR_NONE;
}

// ------------------------------------------------------------------
// Button state queries
// ------------------------------------------------------------------

// Resolve action to a set of raw engine button bits, then test
// against the pad's current physical state
static bool testBits(unsigned int physical, unsigned int actionVal) {
    // The engine stores the button mask directly in the action map.
    // ANY of the bits set in actionVal must be set in physical.
    return (physical & actionVal) != 0;
}

bool C_4JInput::ButtonDown(int iPad, unsigned char ucAction) {
    if (iPad < 0 || iPad >= MAX_PADS) return false;
    if (ucAction == 255) return s_btnCurrent[iPad] != 0;
    unsigned int av = actionBits(iPad, ucAction);
    return testBits(s_btnCurrent[iPad], av);
}

bool C_4JInput::ButtonPressed(int iPad, unsigned char ucAction) {
    if (iPad < 0 || iPad >= MAX_PADS) return false;
    unsigned int av = actionBits(iPad, ucAction);
    return testBits(s_btnCurrent[iPad], av) && !testBits(s_btnPrev[iPad], av);
}

bool C_4JInput::ButtonReleased(int iPad, unsigned char ucAction) {
    if (iPad < 0 || iPad >= MAX_PADS) return false;
    unsigned int av = actionBits(iPad, ucAction);
    return !testBits(s_btnCurrent[iPad], av) && testBits(s_btnPrev[iPad], av);
}

unsigned int C_4JInput::GetValue(int iPad, unsigned char ucAction, bool) {
    return ButtonDown(iPad, ucAction) ? 1u : 0u;
}

// ------------------------------------------------------------------
// Analog sticks
// ------------------------------------------------------------------
float C_4JInput::GetJoypadStick_LX(int iPad, bool) {
    return (iPad >= 0 && iPad < MAX_PADS) ? s_lx[iPad] : 0.0f;
}
float C_4JInput::GetJoypadStick_LY(int iPad, bool) {
    return (iPad >= 0 && iPad < MAX_PADS) ? s_ly[iPad] : 0.0f;
}
float C_4JInput::GetJoypadStick_RX(int iPad, bool) {
    return (iPad >= 0 && iPad < MAX_PADS) ? s_rx[iPad] : 0.0f;
}
float C_4JInput::GetJoypadStick_RY(int iPad, bool) {
    return (iPad >= 0 && iPad < MAX_PADS) ? s_ry[iPad] : 0.0f;
}
unsigned char C_4JInput::GetJoypadLTrigger(int iPad, bool) {
    return (iPad >= 0 && iPad < MAX_PADS) ? s_lt[iPad] : 0;
}
unsigned char C_4JInput::GetJoypadRTrigger(int iPad, bool) {
    return (iPad >= 0 && iPad < MAX_PADS) ? s_rt[iPad] : 0;
}

// ------------------------------------------------------------------
// Hotbar / scroll (no scroll wheel on Wii; D-pad up/down can cycle)
// ------------------------------------------------------------------
int C_4JInput::GetHotbarSlotPressed(int) { return -1; }
int C_4JInput::GetScrollDelta() { return s_scrollSnap; }
